import 'package:flutter/material.dart';
import 'package:quotes_app/model/category_model.dart';
import 'package:quotes_app/model/quotes_model.dart';

class Global {

  static Global g1 = Global();

List<CategoryModel>categoryList=[
    CategoryModel(name:'Motivational',color:Colors.yellow,image:"assets/images/Motivation.png"),
    CategoryModel(name:'Single',color:Colors.brown.shade300,image:"assets/images/Single.png"),
    CategoryModel(name:'Lonely',color:Colors.blue,image:"assets/images/Lonely.png"),
    CategoryModel(name:'Attitude',color:Colors.pink.shade800,image:"assets/images/Attitude.png"),
    CategoryModel(name:'Happiness',color:Colors.pink.shade200,image:"assets/images/Happiness.png"),
    CategoryModel(name:'Sad',color:Colors.brown.shade300,image:"assets/images/Sad.png"),
    CategoryModel(name:'Funny',color:Colors.pink,image:"assets/images/Funny.png"),
    CategoryModel(name:'Beautiful',color:Colors.orange.shade400,image:"assets/images/Beautiful.png"),
    CategoryModel(name:'Best',color:Colors.green.shade400,image:"assets/images/Best.png"),
    CategoryModel(name:'Work',color:Colors.purple.shade400,image:"assets/images/Work.png"),
    CategoryModel(name:'Romentic',color:Colors.red,image:"assets/images/Romentic.png"),
    CategoryModel(name:'Love',color:Colors.pink.shade800,image:"assets/images/Love.png"),
    CategoryModel(name:'Success',color:Colors.pink.shade200,image:"assets/images/Success.png"),
    CategoryModel(name:'Thinking',color:Colors.brown.shade300,image:"assets/images/Thinking.png"),
  ];
  List<Map>quotesList = [
      {'qoutes':'“All our dreams can come true; if we have the courage to pursue them.”','author':'– Walt Disney','category':'Success'},
      {'qoutes':'“There is little success where there is little laughter.”',             'author':' – Andrew Carnegie','category':'Success'},
      {'qoutes':'“There is no substitute for victory.”',                                 'author':' – Douglas MacArthur','category':'Success'},
      {'qoutes':'“They succeed, because they think they can.”',                          'author':' – Virgil','category':'Success'},
      {'qoutes':'“It takes 20 years to make an overnight success.”',                     'author':' – Eddie Cantor','category':'Success'},
      {'qoutes':'“Victory has a thousand fathers, but defeat is an orphan.”',            'author':' – John F. Kennedy','category':'Success'},
      {'qoutes':'“If you have no critics you’ll likely have no success.” ',              'author':'– Malcolm X','category':'Success'},
      {'qoutes':'“Success is never accidental.”',                                        'author':'– Jack Dorsey','category':'Success'},
      {'qoutes':'“Doubt kills more dreams than failure ever will.”',                     'author':'– Suzy Kassem','category':'Success'},
      {'qoutes':'“The best revenge is massive success.”',                                'author':' – Frank Sinatra','category':'Success'},
      ];

  List<QuotesModel>modelList = [];
}