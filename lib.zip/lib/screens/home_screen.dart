import 'package:flutter/material.dart';
import 'package:quotes_app/model/quotes_model.dart';
import 'package:quotes_app/utils/global.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        appBar: AppBar(
          centerTitle: true,
          title: Text(
            " Welcome To Quotes",
            style: TextStyle(fontSize: 20, color: Colors.white),
          ),
          backgroundColor: Colors.teal,
        ),
        body: Padding(
            padding: const EdgeInsets.all(1),
            child: GridView.builder(
              itemCount:Global.g1.categoryList.length,
              gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2, mainAxisExtent:155),
              itemBuilder: (context, index) => InkWell(
                  onTap: () {
                    List<QuotesModel> dataList = [];

                    Navigator.pushNamed(context, "quotes");
                  },
                  child: containerTile(index)),
            ),
        ),
      ),
    );
  }

  Container containerTile(int index) {
    return Container(
      height: 150,
      width: 250,
      margin: EdgeInsets.all(10),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(10),
        color:Global.g1.categoryList[index].color,
      ),
      child: Padding(
        padding: const EdgeInsets.all(10),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              "${Global.g1.categoryList[index].name}",
              style: TextStyle(color: Colors.white,fontWeight: FontWeight.bold,fontSize:17),
            ),
            SizedBox(height:30,),
            Align(alignment: Alignment.bottomRight,
                child: Image.asset("${Global.g1.categoryList[index].image}",height:60,width:60,)),

          ],
        ),
      ),
    );
  }
}