import 'package:flutter/material.dart';
import 'package:quotes_app/utils/global.dart';

class QuoatesScreen extends StatefulWidget {
  const QuoatesScreen({super.key});

  @override
  State<QuoatesScreen> createState() => _QuoatesScreenState();
}

class _QuoatesScreenState extends State<QuoatesScreen> {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
      appBar: AppBar(
        centerTitle: true,
        title: Text(
          "Funny Quotes",
          style: TextStyle(fontSize: 20, color: Colors.white),
        ),
        backgroundColor: Colors.teal,
      ),
      body: ListView.builder(
        itemCount:Global.g1.categoryList.length,
        itemBuilder: (context, index) => squareTile(index),
      ),
    ));
  }

  Container squareTile(int index) {
    return Container(
      height: 200,
      margin: EdgeInsets.all(30),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(10),
        color:Global.g1.categoryList[index].color,
      ),
    );
  }
}