class QuotesModel {
  String? qoutes, author, category;

  QuotesModel({this.qoutes, this.author, this.category});

  factory QuotesModel.fromMap(Map m1) {
    QuotesModel q1 = QuotesModel(
        author: m1['author'], category: m1['category'], qoutes: m1['quotes'],);
    return q1;
  }
}