import 'dart:ui';

class CategoryModel {
  String? name, image;
  Color? color;

  CategoryModel({this.name, this.image, this.color});
}